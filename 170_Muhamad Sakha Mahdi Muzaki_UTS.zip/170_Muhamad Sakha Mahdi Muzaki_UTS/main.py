
# UTS Dasar Komputer dan Pemrograman
# Kelompok C - Instrumentasi
# Monitoring Level Tangki

# 1. DATA INPUT
data_level = [
    18, 25, 33, 41, 55,
    62, 76, 84, 91, 47,
    29, 38, 70, 82, 15,
    29, 30, 31, 79, 81
]

# 2. FUNCTION MENENTUKAN STATUS
def status_level(level):
    if level < 30:
        return "LOW"
    elif level <= 80:
        return "NORMAL"
    else:
        return "HIGH"


# 3. FUNCTION MENGHITUNG KATEGORI
def hitung_kategori(data):
    jumlah = {
        "LOW": 0,
        "NORMAL": 0,
        "HIGH": 0
    }

    for level in data:
        status = status_level(level)
        jumlah[status] += 1

    return jumlah


# 4. FUNCTION MENGHITUNG RATA-RATA
def rata_rata(data):
    return sum(data) / len(data)


# 5. PROGRAM UTAMA
print("===== MONITORING LEVEL TANGKI =====")

for nomor, level in enumerate(data_level, start=1):
    status = status_level(level)
    print(f"{nomor:02d}. Level = {level}% -> {status}")


# 6. RINGKASAN
jumlah = hitung_kategori(data_level)

print("\n===== RINGKASAN =====")
print("Total data :", len(data_level))
print("Jumlah LOW :", jumlah["LOW"])
print("Jumlah NORMAL :", jumlah["NORMAL"])
print("Jumlah HIGH :", jumlah["HIGH"])
print("Rata-rata :", rata_rata(data_level), "%")
print("Maksimum :", max(data_level), "%")
print("Minimum :", min(data_level), "%")


# 7. PENGUJIAN PROGRAM
print("\n===== PENGUJIAN PROGRAM =====")

data_uji = [29, 30, 31, 79, 80, 81, 5, 95]

hasil_diharapkan = [
    "LOW", "NORMAL", "NORMAL", "NORMAL",
    "NORMAL", "HIGH", "LOW", "HIGH"
]

for nomor, level in enumerate(data_uji, start=1):
    hasil_aktual = status_level(level)

    if hasil_aktual == hasil_diharapkan[nomor - 1]:
        status_uji = "PASS"
    else:
        status_uji = "FAIL"

    print(f"Uji {nomor}: {level}% | Harapan: {hasil_diharapkan[nomor - 1]} | Aktual: {hasil_aktual} | {status_uji}")